export const RegistroMessage = {
    'auth/email-already-in-use': 'El email ya se encuentra registrado',
    'auth/weak-password': 'Ingrese una contraseña válida'
}

export const LoginMessage = {
    'auth/user-not-found': 'El email no se encuentra registrado',
    'auth/wrong-password': 'Contraseña incorrecta'
}